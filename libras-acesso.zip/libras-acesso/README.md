# Libras Acesso

Aplicativo web de acessibilidade para pessoas surdas e com deficiência auditiva.

**Recursos:** dicionário de sinais com busca e favoritos, alfabeto e soletração, lições com quiz, cartões de comunicação em tela cheia, legendas ao vivo (fala para texto), alerta visual e por vibração para sons altos, painel de acessibilidade (texto até 200%, alto contraste, tema claro/escuro, menos animação, mais espaçamento) e instalação como app (PWA).

**Tecnologias:** HTML5, CSS3, JavaScript ES6 (módulos), Node.js + Express, MySQL ou Supabase (Postgres), deploy no Render.

## Estrutura

```
frontend/        HTML, CSS e JS do app (sem etapa de build)
backend/
  src/server.js  Servidor Express: API em /api e frontend estático
  src/db/        memory.js, mysql.js e supabase.js (mesma interface)
  sql/           mysql_schema.sql e supabase_schema.sql
  data/          seed.json (conteúdo inicial)
  scripts/       seed.js (carrega o banco) e build.js (gera o protótipo)
  test/          testes automatizados da API
prototype/       libras-acesso-prototipo.html (arquivo único, abre com duplo clique)
render.yaml      Configuração de deploy no Render
```

## Rodar localmente

```bash
cd backend
npm install
cp .env.example .env     # DB_PROVIDER=memory funciona sem banco nenhum
npm start                # http://localhost:3000
npm test
```

O microfone (legendas e alerta de som) exige `https` ou `localhost`.

## Escolher o banco de dados

Defina `DB_PROVIDER` no `.env` (ou no painel do Render):

| Valor | Quando usar | Variáveis |
|---|---|---|
| `memory` | Testes e demonstração. Dados somem ao reiniciar. | nenhuma |
| `supabase` | Produção com Postgres gerenciado. | `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` |
| `mysql` | Produção com MySQL/MariaDB. | `DATABASE_URL` (ou `MYSQL_*`), `MYSQL_SSL` |

### Supabase
1. Crie um projeto em supabase.com.
2. No **SQL Editor**, rode `backend/sql/supabase_schema.sql`.
3. Em **Project Settings > API**, copie a URL e a chave `service_role` para as variáveis.
4. `DB_PROVIDER=supabase npm run seed` carrega os sinais, lições e frases.

A chave `service_role` ignora o RLS. Use apenas no servidor, nunca no frontend nem em repositório público. As tabelas de usuário têm RLS ligado e nenhuma policy, então só o servidor acessa.

### MySQL
1. Crie um banco vazio (utf8mb4).
2. Configure `DATABASE_URL=mysql://usuario:senha@host:3306/banco`.
3. `DB_PROVIDER=mysql npm run seed` cria as tabelas (`sql/mysql_schema.sql`) e carrega o conteúdo.

## Publicar no Render

1. Suba o projeto para um repositório no GitHub.
2. No Render: **New > Blueprint** e escolha o repositório (usa o `render.yaml`).
3. Preencha as variáveis marcadas como secretas no painel.
4. Rode o seed uma vez (pelo seu computador, com as variáveis do banco de produção).
5. O Render usa `/api/health` para verificar o serviço.

No plano gratuito o serviço dorme após inatividade, e a primeira requisição pode demorar. O app continua funcionando com dados locais enquanto isso.

## API

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/health` | Estado do servidor e do banco |
| GET | `/api/categories` | Categorias |
| GET | `/api/signs?q=&category=&limit=` | Sinais (busca ignora acentos) |
| GET | `/api/signs/:id` | Um sinal |
| GET | `/api/lessons` | Lições |
| GET | `/api/phrases` | Frases dos cartões |
| GET/PUT/DELETE | `/api/users/:userId/favorites[/:signId]` | Favoritos |
| GET/POST | `/api/users/:userId/attempts` | Pontuações de quiz |
| DELETE | `/api/users/:userId` | Apaga os dados do usuário |
| POST | `/api/feedback` | Envia sugestão |

`userId` é um código anônimo (UUID) gerado no aparelho. Não há login nesta versão.

## Antes de publicar de verdade

- **Conteúdo de Libras:** os sinais são exemplos escritos para demonstrar o app. Substitua por vídeos e descrições revisados por intérpretes e pessoas surdas fluentes. Grave a URL em `video_url` e marque `validated = true`. No Supabase, use um bucket público do Storage.
- **Contas de usuário:** o código anônimo não protege dados. Se quiser sincronizar entre aparelhos, adicione login (Supabase Auth) e ajuste as policies de RLS.
- **Alerta de som:** mede só volume e não identifica o tipo de som. Não use como único aviso de segurança.
- **Legendas ao vivo:** usam o reconhecimento de voz do navegador (Chrome/Edge), que pode enviar áudio a um serviço online.
- **Privacidade (LGPD):** informe no app quais dados são guardados e por quê. O botão "Apagar meus dados" já remove favoritos e pontuações.
- **Imagens do alfabeto:** coloque `A.png` a `Z.png` em uma pasta e aponte `ALPHABET_IMAGE_BASE` em `frontend/config.js`.
