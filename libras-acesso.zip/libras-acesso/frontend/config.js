// Configuração do frontend (carregada antes do app).
window.APP_CONFIG = {
  // URL base da API. Deixe vazio quando o servidor Node serve o frontend (mesma origem).
  // Se o frontend estiver em outro domínio, use a URL do Render, ex.: 'https://libras-acesso.onrender.com'
  API_URL: '',

  // Pasta com imagens do alfabeto manual (A.png ... Z.png), ex.: '/assets/alfabeto'.
  // Deixe null para mostrar apenas a letra.
  ALPHABET_IMAGE_BASE: null,

  // Registra o service worker (instalação como app e uso offline).
  PWA: true
};
