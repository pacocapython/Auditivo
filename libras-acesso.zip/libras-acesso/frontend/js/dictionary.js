import { $, el, normalize, debounce, openDialog, closeDialog, wireDialog, safeUrl } from './ui.js';
import { state, on, emit, toggleFavorite, categoryName, signById } from './state.js';

let dictCategory = 'todos';

const favLabel = (sign, isFavorite) => (isFavorite ? `Remover ${sign.word} dos favoritos` : `Adicionar ${sign.word} aos favoritos`);

/** Botão de estrela dos cartões. */
function favIconButton(sign) {
  const isFavorite = state.favorites.has(sign.id);
  return el(
    'button',
    {
      type: 'button',
      class: 'fav-btn',
      'data-fav': sign.id,
      'aria-pressed': String(isFavorite),
      'aria-label': favLabel(sign, isFavorite),
      onclick: () => toggleFavorite(sign.id)
    },
    el('span', { 'aria-hidden': 'true', text: isFavorite ? '★' : '☆' })
  );
}

/** Botão de texto do diálogo de detalhes. */
function favTextButton(sign) {
  const isFavorite = state.favorites.has(sign.id);
  return el('button', {
    type: 'button',
    class: 'btn',
    'data-favtext': sign.id,
    'aria-pressed': String(isFavorite),
    onclick: () => toggleFavorite(sign.id),
    text: isFavorite ? '★ Nos favoritos' : '☆ Favoritar'
  });
}

/** Atualiza todos os botões de favorito visíveis. */
function syncFavButtons() {
  document.querySelectorAll('[data-fav]').forEach((button) => {
    const sign = signById(button.dataset.fav);
    if (!sign) return;
    const isFavorite = state.favorites.has(sign.id);
    button.setAttribute('aria-pressed', String(isFavorite));
    button.setAttribute('aria-label', favLabel(sign, isFavorite));
    button.firstChild.textContent = isFavorite ? '★' : '☆';
  });
  document.querySelectorAll('[data-favtext]').forEach((button) => {
    const isFavorite = state.favorites.has(button.dataset.favtext);
    button.setAttribute('aria-pressed', String(isFavorite));
    button.textContent = isFavorite ? '★ Nos favoritos' : '☆ Favoritar';
  });
}

export function signCard(sign) {
  return el(
    'li',
    { class: 'sign-card' },
    el(
      'button',
      { type: 'button', class: 'sign-open', onclick: () => openSignDialog(sign.id) },
      el('span', { class: 'sign-emoji', 'aria-hidden': 'true', text: sign.emoji ?? '' }),
      el('span', { class: 'sign-word', text: sign.word }),
      el('span', { class: 'sign-cat', text: categoryName(sign.category) })
    ),
    favIconButton(sign)
  );
}

function buildSignMedia(sign) {
  const video = safeUrl(sign.videoUrl);
  const image = safeUrl(sign.imageUrl);

  if (video) {
    const player = el('video', {
      controls: true,
      playsinline: true,
      preload: 'metadata',
      src: video,
      'aria-label': `Vídeo do sinal ${sign.word}`
    });
    const slow = el('button', {
      type: 'button',
      class: 'btn',
      'aria-pressed': 'false',
      text: 'Ver em câmera lenta',
      onclick: (event) => {
        const enable = player.playbackRate !== 0.5;
        player.playbackRate = enable ? 0.5 : 1;
        event.currentTarget.setAttribute('aria-pressed', String(enable));
        event.currentTarget.textContent = enable ? 'Câmera lenta ligada' : 'Ver em câmera lenta';
      }
    });
    return el('div', { class: 'sign-media' }, player, slow);
  }
  if (image) {
    return el('div', { class: 'sign-media' }, el('img', { src: image, alt: `Sinal de ${sign.word} em Libras` }));
  }
  return el(
    'div',
    { class: 'sign-media' },
    el('span', { class: 'big', 'aria-hidden': 'true', text: sign.emoji ?? '' }),
    el('p', { class: 'muted', text: 'O vídeo deste sinal ainda não foi adicionado.' })
  );
}

export function openSignDialog(id) {
  const sign = signById(id);
  if (!sign) return;
  const dialog = $('#sign-dialog');
  $('#sign-title').textContent = sign.word;

  $('#sign-body').replaceChildren(
    buildSignMedia(sign),
    el('p', {}, el('span', { class: `badge ${sign.validated ? 'ok' : 'warn'}`, text: sign.validated ? 'Revisado por intérprete' : 'Exemplo, ainda sem revisão' })),
    el('h3', { text: 'Como fazer' }),
    el('p', { text: sign.description }),
    sign.tip ? el('p', { class: 'muted', text: `Dica: ${sign.tip}` }) : null,
    el('p', { class: 'muted', text: `Categoria: ${categoryName(sign.category)}` }),
    el(
      'div',
      { class: 'btn-row' },
      favTextButton(sign),
      el('button', {
        type: 'button',
        class: 'btn',
        text: 'Ver soletração',
        onclick: () => {
          closeDialog(dialog);
          emit('spell', sign.word);
          location.hash = '#alfabeto';
        }
      })
    )
  );
  openDialog(dialog);
}

export function initDictionary() {
  const input = $('#dict-search');
  const chips = $('#dict-chips');
  const grid = $('#dict-grid');
  const status = $('#dict-status');
  const empty = $('#dict-empty');

  wireDialog($('#sign-dialog'));

  const filters = [{ id: 'todos', name: 'Todos' }, { id: 'favoritos', name: 'Favoritos' }, ...state.categories];
  chips.replaceChildren(
    ...filters.map((filter) =>
      el('button', {
        type: 'button',
        class: 'chip-btn',
        'data-filter': filter.id,
        'aria-pressed': String(filter.id === dictCategory),
        text: filter.name,
        onclick: () => {
          dictCategory = filter.id;
          chips.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.filter === dictCategory)));
          render();
        }
      })
    )
  );

  function matches(sign) {
    if (dictCategory === 'favoritos' && !state.favorites.has(sign.id)) return false;
    if (dictCategory !== 'todos' && dictCategory !== 'favoritos' && sign.category !== dictCategory) return false;
    const term = normalize(input.value);
    return !term || normalize(`${sign.word} ${sign.description} ${categoryName(sign.category)}`).includes(term);
  }

  function render() {
    const list = state.signs.filter(matches).sort((a, b) => a.word.localeCompare(b.word, 'pt-BR'));
    grid.replaceChildren(...list.map(signCard));
    empty.hidden = list.length > 0;
    status.textContent = list.length === 1 ? '1 sinal encontrado' : `${list.length} sinais encontrados`;
  }

  input.addEventListener('input', debounce(render, 200));
  on('favorites', () => {
    syncFavButtons();
    if (dictCategory === 'favoritos') {
      render();
      input.focus();
    }
  });
  render();
}
