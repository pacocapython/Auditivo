import { $, $$, announce } from './ui.js';
import { emit } from './state.js';

const VIEWS = {
  inicio: 'Início',
  dicionario: 'Dicionário',
  alfabeto: 'Alfabeto',
  aprender: 'Aprender',
  comunicar: 'Comunicar',
  legendas: 'Legendas ao vivo',
  alerta: 'Alerta de som',
  progresso: 'Meu progresso'
};

let firstNavigation = true;

function navigate() {
  const requested = location.hash.replace('#', '');
  const view = Object.hasOwn(VIEWS, requested) ? requested : 'inicio';

  $$('[data-view]').forEach((section) => {
    section.hidden = section.dataset.view !== view;
  });
  $$('.main-nav a').forEach((link) => {
    if (link.getAttribute('href') === `#${view}`) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  document.title = `${VIEWS[view]} · Libras Acesso`;
  window.scrollTo(0, 0);

  // Depois da primeira carga, leva o foco para o título da nova página.
  if (!firstNavigation) {
    $(`[data-view="${view}"] h1`)?.focus();
    announce(`Página ${VIEWS[view]}`);
  }
  firstNavigation = false;
  emit('route', view);
}

export function initRouter() {
  window.addEventListener('hashchange', navigate);
  navigate();
}
