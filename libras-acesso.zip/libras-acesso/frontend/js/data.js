// Gerado por backend/scripts/build.js a partir de backend/data/seed.json. Não edite à mão.
export const OFFLINE_DATA = {
  "categories": [
    {
      "id": "saudacoes",
      "name": "Saudações",
      "icon": "👋"
    },
    {
      "id": "basico",
      "name": "Básico",
      "icon": "💬"
    },
    {
      "id": "saude",
      "name": "Saúde e emergência",
      "icon": "🚑"
    },
    {
      "id": "casa",
      "name": "Casa e família",
      "icon": "🏠"
    },
    {
      "id": "alimentos",
      "name": "Comida e bebida",
      "icon": "🍽️"
    }
  ],
  "signs": [
    {
      "id": "oi",
      "word": "Oi / Olá",
      "category": "saudacoes",
      "emoji": "👋",
      "description": "Mão aberta perto da lateral da cabeça, com um pequeno aceno para fora.",
      "tip": "Acompanhe com expressão facial amigável e contato visual.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "bom-dia",
      "word": "Bom dia",
      "category": "saudacoes",
      "emoji": "🌅",
      "description": "Sinal composto: BOM seguido de DIA.",
      "tip": "Em Libras, a expressão facial faz parte do sinal.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "boa-tarde",
      "word": "Boa tarde",
      "category": "saudacoes",
      "emoji": "🌇",
      "description": "Sinal composto: BOM seguido de TARDE.",
      "tip": "Mantenha o mesmo ritmo e expressão do cumprimento anterior.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "boa-noite",
      "word": "Boa noite",
      "category": "saudacoes",
      "emoji": "🌙",
      "description": "Sinal composto: BOM seguido de NOITE.",
      "tip": "Serve para cumprimentar e para se despedir à noite.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "tchau",
      "word": "Tchau",
      "category": "saudacoes",
      "emoji": "🙋",
      "description": "Mão aberta com movimento de aceno de despedida.",
      "tip": "O aceno é visível de longe, bom para chamar atenção.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "obrigado",
      "word": "Obrigado(a)",
      "category": "basico",
      "emoji": "🙏",
      "description": "Mão aberta toca perto do queixo e se afasta para frente.",
      "tip": "O mesmo sinal vale para obrigado e obrigada.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "por-favor",
      "word": "Por favor",
      "category": "basico",
      "emoji": "🤲",
      "description": "Mão aberta sobre o peito, com movimento circular.",
      "tip": "Use expressão gentil, ela muda o tom do pedido.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "desculpa",
      "word": "Desculpa",
      "category": "basico",
      "emoji": "😔",
      "description": "Movimento junto ao peito que expressa pedido de desculpas.",
      "tip": "Confirme a configuração de mão com um instrutor de Libras.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "sim",
      "word": "Sim",
      "category": "basico",
      "emoji": "✅",
      "description": "Mão fechada balança para baixo e para cima, como um aceno de cabeça.",
      "tip": "Acompanhe com um aceno de cabeça.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "nao",
      "word": "Não",
      "category": "basico",
      "emoji": "❌",
      "description": "Dedo indicador balança de um lado para o outro.",
      "tip": "Acompanhe com um aceno de cabeça negativo.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "amigo",
      "word": "Amigo(a)",
      "category": "basico",
      "emoji": "🤝",
      "description": "As duas mãos se encontram à frente do corpo, indicando união.",
      "tip": "Confirme a forma exata das mãos com um instrutor de Libras.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "onde",
      "word": "Onde?",
      "category": "basico",
      "emoji": "❓",
      "description": "Sinal de pergunta feito com a mão, acompanhado de expressão interrogativa.",
      "tip": "Perguntas em Libras usam sobrancelhas franzidas e cabeça levemente inclinada.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "banheiro",
      "word": "Banheiro",
      "category": "basico",
      "emoji": "🚻",
      "description": "Sinal próprio para BANHEIRO, feito perto do corpo.",
      "tip": "Adicione o vídeo do sinal validado para este item.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "ajuda",
      "word": "Ajuda",
      "category": "saude",
      "emoji": "🆘",
      "description": "Uma mão apoia a outra por baixo e ambas se movem para cima.",
      "tip": "Em emergência, combine com expressão de urgência.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "medico",
      "word": "Médico(a)",
      "category": "saude",
      "emoji": "🩺",
      "description": "Dedos tocam o pulso, lembrando a verificação do pulso.",
      "tip": "Vale para médico e médica.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "hospital",
      "word": "Hospital",
      "category": "saude",
      "emoji": "🏥",
      "description": "Sinal que remete a MÉDICO e a um local de atendimento.",
      "tip": "Adicione o vídeo validado para mostrar a forma correta.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "emergencia",
      "word": "Emergência",
      "category": "saude",
      "emoji": "🚨",
      "description": "Sinal rápido e enfático, com expressão de urgência.",
      "tip": "No Brasil: SAMU 192, Bombeiros 193, Polícia 190.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "dor",
      "word": "Dor",
      "category": "saude",
      "emoji": "🤕",
      "description": "Dedos indicadores se movem em direções opostas perto do local da dor.",
      "tip": "Aponte o local do corpo onde dói.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "casa",
      "word": "Casa",
      "category": "casa",
      "emoji": "🏠",
      "description": "As duas mãos formam o telhado de uma casa.",
      "tip": "O desenho do telhado ajuda a memorizar o sinal.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "familia",
      "word": "Família",
      "category": "casa",
      "emoji": "👨‍👩‍👧",
      "description": "Mãos desenham um círculo à frente do corpo, indicando um grupo unido.",
      "tip": "Confirme a configuração de mão com um instrutor de Libras.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "bebe",
      "word": "Bebê",
      "category": "casa",
      "emoji": "👶",
      "description": "Os braços embalam um bebê imaginário.",
      "tip": "Sinal icônico: imita o gesto de embalar.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "agua",
      "word": "Água",
      "category": "alimentos",
      "emoji": "💧",
      "description": "Movimento junto à boca que remete a água.",
      "tip": "Confirme a configuração de mão com um instrutor de Libras.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "comer",
      "word": "Comer",
      "category": "alimentos",
      "emoji": "🍽️",
      "description": "Dedos juntos são levados à boca repetidamente.",
      "tip": "Também pode significar comida, dependendo do contexto.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "beber",
      "word": "Beber",
      "category": "alimentos",
      "emoji": "🥤",
      "description": "A mão em formato de copo é levada à boca e inclina como se bebesse.",
      "tip": "Sinal icônico: imita o gesto de beber.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    },
    {
      "id": "cafe",
      "word": "Café",
      "category": "alimentos",
      "emoji": "☕",
      "description": "Uma mão fechada gira ao lado da outra, como moer café.",
      "tip": "O movimento imita um moedor manual.",
      "videoUrl": null,
      "imageUrl": null,
      "validated": false
    }
  ],
  "lessons": [
    {
      "id": "licao-saudacoes",
      "title": "Saudações",
      "description": "Cumprimentos para começar e encerrar uma conversa.",
      "signIds": [
        "oi",
        "bom-dia",
        "boa-tarde",
        "boa-noite",
        "tchau"
      ]
    },
    {
      "id": "licao-basico",
      "title": "Educação e respostas",
      "description": "Agradecer, pedir desculpas e responder sim ou não.",
      "signIds": [
        "obrigado",
        "por-favor",
        "desculpa",
        "sim",
        "nao"
      ]
    },
    {
      "id": "licao-saude",
      "title": "Saúde e emergência",
      "description": "Sinais para pedir ajuda e falar de saúde.",
      "signIds": [
        "ajuda",
        "medico",
        "hospital",
        "emergencia",
        "dor"
      ]
    },
    {
      "id": "licao-casa",
      "title": "Casa e família",
      "description": "Pessoas e lugares do dia a dia.",
      "signIds": [
        "casa",
        "familia",
        "bebe",
        "amigo"
      ]
    },
    {
      "id": "licao-alimentos",
      "title": "Comida e bebida",
      "description": "Pedir e falar sobre alimentos e bebidas.",
      "signIds": [
        "agua",
        "comer",
        "beber",
        "cafe"
      ]
    }
  ],
  "phrases": [
    {
      "id": "f-ola",
      "text": "Olá! Tudo bem?",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-bomdia",
      "text": "Bom dia! Boa tarde! Boa noite!",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-nome",
      "text": "Meu nome é…",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-prazer",
      "text": "Prazer em conhecer!",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-licenca",
      "text": "Com licença.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-desculpa",
      "text": "Desculpa.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-repetir",
      "text": "Pode repetir, por favor?",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-devagar",
      "text": "Mais devagar, por favor.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-entendi",
      "text": "Entendi.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-nao-entendi",
      "text": "Não entendi.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-espera",
      "text": "Espera um pouco.",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-onde",
      "text": "Fica onde? É perto?",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-custa",
      "text": "Quanto custa?",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "f-ajuda",
      "text": "Preciso de ajuda.",
      "category": "frequentes",
      "urgent": true
    },
    {
      "id": "f-tchau",
      "text": "Tchau! Até mais!",
      "category": "frequentes",
      "urgent": false
    },
    {
      "id": "p-surdo",
      "text": "Sou surdo(a). Por favor, escreva ou digite no celular para conversarmos.",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-devagar",
      "text": "Fale devagar e de frente para mim, por favor.",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-interprete",
      "text": "Preciso de um intérprete de Libras.",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-escrever",
      "text": "Você pode escrever, por favor?",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-repetir",
      "text": "Não entendi. Pode repetir por escrito?",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-obrigado",
      "text": "Muito obrigado(a)!",
      "category": "essencial",
      "urgent": false
    },
    {
      "id": "p-medico",
      "text": "Preciso de atendimento médico.",
      "category": "saude",
      "urgent": true
    },
    {
      "id": "p-ambulancia",
      "text": "Chame uma ambulância, por favor.",
      "category": "saude",
      "urgent": true
    },
    {
      "id": "p-dor",
      "text": "Estou com dor. Preciso de ajuda.",
      "category": "saude",
      "urgent": true
    },
    {
      "id": "p-alergia",
      "text": "Tenho alergia. Preciso avisar a equipe de saúde.",
      "category": "saude",
      "urgent": false
    },
    {
      "id": "p-banheiro",
      "text": "Onde fica o banheiro?",
      "category": "cotidiano",
      "urgent": false
    },
    {
      "id": "p-preco",
      "text": "Quanto custa? Pode digitar o valor?",
      "category": "cotidiano",
      "urgent": false
    },
    {
      "id": "p-ajuda",
      "text": "Pode me ajudar, por favor?",
      "category": "cotidiano",
      "urgent": false
    },
    {
      "id": "p-saida",
      "text": "Onde fica a saída?",
      "category": "cotidiano",
      "urgent": false
    }
  ]
};
