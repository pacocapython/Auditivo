import { api } from './api.js';
import { announce } from './ui.js';

// Estado compartilhado entre as telas.
export const state = {
  signs: [],
  categories: [],
  lessons: [],
  phrases: [],
  favorites: new Set(),
  attempts: [],
  source: 'offline'
};

const bus = new EventTarget();
export const emit = (name, detail) => bus.dispatchEvent(new CustomEvent(name, { detail }));
export const on = (name, handler) => bus.addEventListener(name, (event) => handler(event.detail));

export const categoryName = (id) => state.categories.find((c) => c.id === id)?.name ?? id;
export const signById = (id) => state.signs.find((s) => s.id === id);

export async function toggleFavorite(signId) {
  const nowFavorite = !state.favorites.has(signId);
  if (nowFavorite) state.favorites.add(signId);
  else state.favorites.delete(signId);
  announce(nowFavorite ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.');
  emit('favorites', { signId, nowFavorite });
  await api.setFavorite(signId, nowFavorite);
  return nowFavorite;
}
