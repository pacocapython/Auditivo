import { $, openDialog, wireDialog } from './ui.js';
import { storage } from './storage.js';

const DEFAULT_SETTINGS = { fontScale: 100, theme: 'auto', contrast: false, motion: false, spacing: false, flash: true, vibrate: true };
export const settings = { ...DEFAULT_SETTINGS, ...storage.get('settings', {}) };

let themeApplied = false;

function applySettings() {
  const root = document.documentElement;
  root.style.setProperty('--fs', String(settings.fontScale / 100));

  // Só mexe no tema se a pessoa escolheu um (ou se fomos nós que o definimos antes).
  if (settings.theme !== 'auto') {
    root.setAttribute('data-theme', settings.theme);
    themeApplied = true;
  } else if (themeApplied) {
    root.removeAttribute('data-theme');
    themeApplied = false;
  }

  root.dataset.contrast = settings.contrast ? 'high' : 'normal';
  root.dataset.motion = settings.motion ? 'reduce' : 'normal';
  root.dataset.spacing = settings.spacing ? 'wide' : 'normal';
  root.dataset.flash = settings.flash ? 'on' : 'off';
  root.dataset.vibrate = settings.vibrate ? 'on' : 'off';
}

function syncControls() {
  $('#opt-fontsize').value = settings.fontScale;
  $('#opt-fontsize-out').textContent = `${settings.fontScale}%`;
  document.querySelectorAll('input[name="opt-theme"]').forEach((radio) => {
    radio.checked = radio.value === settings.theme;
  });
  $('#opt-contrast').checked = settings.contrast;
  $('#opt-motion').checked = settings.motion;
  $('#opt-spacing').checked = settings.spacing;
  $('#opt-flash').checked = settings.flash;
  $('#opt-vibrate').checked = settings.vibrate;
}

function update(patch) {
  Object.assign(settings, patch);
  storage.set('settings', settings);
  applySettings();
}

export function initA11y() {
  applySettings();
  syncControls();

  const dialog = $('#a11y-dialog');
  wireDialog(dialog);
  $('#a11y-open').addEventListener('click', () => openDialog(dialog));

  $('#opt-fontsize').addEventListener('input', (event) => {
    const value = Number(event.target.value);
    $('#opt-fontsize-out').textContent = `${value}%`;
    update({ fontScale: value });
  });
  document.querySelectorAll('input[name="opt-theme"]').forEach((radio) => {
    radio.addEventListener('change', () => update({ theme: radio.value }));
  });
  $('#opt-contrast').addEventListener('change', (e) => update({ contrast: e.target.checked }));
  $('#opt-motion').addEventListener('change', (e) => update({ motion: e.target.checked }));
  $('#opt-spacing').addEventListener('change', (e) => update({ spacing: e.target.checked }));
  $('#opt-flash').addEventListener('change', (e) => update({ flash: e.target.checked }));
  $('#opt-vibrate').addEventListener('change', (e) => update({ vibrate: e.target.checked }));
  $('#opt-reset').addEventListener('click', () => {
    update({ ...DEFAULT_SETTINGS });
    syncControls();
  });
}
