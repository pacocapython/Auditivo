import { $, el, shuffle, announce } from './ui.js';
import { state, on, emit, signById } from './state.js';
import { api } from './api.js';

export function initLearn() {
  const list = $('#lesson-list');
  const panel = $('#lessons-panel');
  const quizEl = $('#quiz');
  let quiz = null; // { lesson, questions, index, score }

  function bestFor(lessonId) {
    const tries = state.attempts.filter((a) => a.lessonId === lessonId);
    if (!tries.length) return null;
    return tries.reduce((best, a) => (a.score / a.total > best.score / best.total ? a : best));
  }

  function renderLessons() {
    list.replaceChildren(
      ...state.lessons.map((lesson) => {
        const best = bestFor(lesson.id);
        return el(
          'li',
          { class: 'lesson-card' },
          el('h2', { text: lesson.title }),
          el('p', { text: lesson.description }),
          el(
            'p',
            {},
            el('span', { class: 'badge', text: `${lesson.signIds.length} sinais` }),
            ' ',
            best
              ? el('span', { class: 'badge ok', text: `Melhor: ${best.score} de ${best.total}` })
              : el('span', { class: 'badge', text: 'Ainda não praticada' })
          ),
          el('button', {
            type: 'button',
            class: 'btn btn-primary',
            'aria-label': `${best ? 'Praticar de novo' : 'Começar'} a lição ${lesson.title}`,
            text: best ? 'Praticar de novo' : 'Começar',
            onclick: () => startLesson(lesson)
          })
        );
      })
    );
  }

  function buildQuestions(lesson) {
    const lessonSigns = lesson.signIds.map(signById).filter(Boolean);
    return shuffle(lessonSigns).map((sign) => {
      const others = shuffle(state.signs.filter((s) => s.id !== sign.id));
      const distractors = [...others.filter((s) => s.category === sign.category), ...others.filter((s) => s.category !== sign.category)].slice(0, 3);
      return { sign, options: shuffle([sign, ...distractors]) };
    });
  }

  function showQuiz(show) {
    panel.hidden = show;
    quizEl.hidden = !show;
  }

  function backToLessons() {
    quiz = null;
    renderLessons();
    showQuiz(false);
    $('#h-apr').focus();
  }

  function startLesson(lesson) {
    const questions = buildQuestions(lesson);
    if (questions.length === 0) return;
    quiz = { lesson, questions, index: 0, score: 0 };
    showQuiz(true);
    renderQuestion();
  }

  function renderQuestion() {
    const question = quiz.questions[quiz.index];
    const total = quiz.questions.length;

    const legend = el('legend', { tabindex: '-1', text: `Pergunta ${quiz.index + 1} de ${total}: qual palavra combina com esta descrição?` });
    const feedback = el('p', { class: 'feedback', role: 'status' });
    const submit = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Responder' });

    const options = el(
      'div',
      { class: 'options' },
      ...question.options.map((option) =>
        el(
          'label',
          { class: 'option', dataset: { id: option.id } },
          el('input', { type: 'radio', name: 'answer', value: option.id }),
          el('span', { text: option.word }),
          el('span', { class: 'mark', 'aria-hidden': 'true' })
        )
      )
    );

    const form = el(
      'form',
      { class: 'quiz-box', novalidate: true },
      el('fieldset', {}, legend, el('p', { class: 'prompt', text: question.sign.description }), options),
      feedback,
      el('div', { class: 'btn-row' }, submit, el('button', { type: 'button', class: 'btn', text: 'Sair da lição', onclick: backToLessons }))
    );

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const chosen = form.querySelector('input[name="answer"]:checked');
      if (!chosen) {
        feedback.textContent = 'Escolha uma opção antes de responder.';
        return;
      }
      const correct = chosen.value === question.sign.id;
      if (correct) quiz.score += 1;

      form.querySelectorAll('.option').forEach((label) => {
        label.querySelector('input').disabled = true;
        const mark = label.querySelector('.mark');
        if (label.dataset.id === question.sign.id) {
          label.classList.add('correct');
          mark.textContent = '✔ Correta';
        } else if (label.dataset.id === chosen.value) {
          label.classList.add('wrong');
          mark.textContent = '✖ Sua resposta';
        }
      });
      feedback.textContent = correct ? 'Correto! Muito bem.' : `Quase. A resposta certa é “${question.sign.word}”.`;

      const isLast = quiz.index === total - 1;
      const nextButton = el('button', {
        type: 'button',
        class: 'btn btn-primary',
        text: isLast ? 'Ver resultado' : 'Próxima pergunta',
        onclick: () => {
          quiz.index += 1;
          if (isLast) finishQuiz();
          else renderQuestion();
        }
      });
      submit.replaceWith(nextButton);
      nextButton.focus();
    });

    quizEl.replaceChildren(
      el('div', { class: 'quiz-head' }, el('h2', { text: quiz.lesson.title }), el('p', { class: 'muted', text: `Acertos até agora: ${quiz.score}` })),
      form
    );
    legend.focus();
  }

  async function finishQuiz() {
    const { lesson, score, questions } = quiz;
    const total = questions.length;
    const record = await api.saveAttempt({ lessonId: lesson.id, score, total });
    state.attempts.unshift(record);
    emit('progress');

    const ratio = score / total;
    const message =
      ratio === 1
        ? 'Perfeito! Você acertou todas.'
        : ratio >= 0.6
          ? 'Bom trabalho! Revise os sinais que errou e tente de novo.'
          : 'Continue praticando. Abra o dicionário para rever os sinais desta lição.';

    quizEl.replaceChildren(
      el(
        'div',
        { class: 'quiz-box' },
        el('h2', { id: 'quiz-result', tabindex: '-1', text: `Resultado: ${lesson.title}` }),
        el('p', { class: 'result-score', text: `${score} de ${total}` }),
        el('p', { text: message }),
        el(
          'div',
          { class: 'btn-row' },
          el('button', { type: 'button', class: 'btn btn-primary', text: 'Tentar de novo', onclick: () => startLesson(lesson) }),
          el('button', { type: 'button', class: 'btn', text: 'Voltar às lições', onclick: backToLessons })
        )
      )
    );
    $('#quiz-result').focus();
    announce(`Lição concluída: ${score} de ${total}.`);
  }

  on('progress', renderLessons);
  renderLessons();
}
