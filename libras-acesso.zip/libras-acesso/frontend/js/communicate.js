import { $, el, announce, openDialog, wireDialog } from './ui.js';
import { state } from './state.js';

const PHRASE_GROUPS = {
  frequentes: 'Mais usadas',
  essencial: 'Essenciais',
  saude: 'Saúde e emergência',
  cotidiano: 'Dia a dia'
};

export function initCommunicate() {
  const groups = $('#phrase-groups');
  const dialog = $('#show-dialog');
  const text = $('#show-text');
  const speakButton = $('#show-speak');
  const form = $('#custom-form');
  const custom = $('#custom-text');

  wireDialog(dialog);

  const canSpeak = 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined';
  speakButton.hidden = !canSpeak;

  function show(message) {
    text.textContent = message;
    openDialog(dialog);
  }

  speakButton.addEventListener('click', () => {
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.textContent);
    utterance.lang = 'pt-BR';
    speechSynthesis.speak(utterance);
  });
  dialog.addEventListener('close', () => {
    if (canSpeak) speechSynthesis.cancel();
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const message = custom.value.trim();
    if (!message) {
      announce('Escreva uma mensagem primeiro.');
      custom.focus();
      return;
    }
    show(message);
  });

  groups.replaceChildren(
    ...Object.entries(PHRASE_GROUPS)
      .map(([key, title]) => {
        const phrases = state.phrases.filter((p) => p.category === key);
        if (!phrases.length) return null;
        return el(
          'section',
          { 'aria-labelledby': `pg-${key}` },
          el('h2', { id: `pg-${key}`, text: title }),
          el(
            'ul',
            { class: 'grid phrase-grid' },
            ...phrases.map((phrase) =>
              el(
                'li',
                {},
                el(
                  'button',
                  { type: 'button', class: `phrase-btn${phrase.urgent ? ' urgent' : ''}`, onclick: () => show(phrase.text) },
                  phrase.urgent ? el('span', { class: 'phrase-tag', text: 'Urgente' }) : null,
                  el('span', { text: phrase.text })
                )
              )
            )
          )
        );
      })
      .filter(Boolean)
  );
}
