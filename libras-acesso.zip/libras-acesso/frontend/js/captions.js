import { $, el, formatTime } from './ui.js';

export function initCaptions() {
  const SpeechRecognitionApi = window.SpeechRecognition || window.webkitSpeechRecognition;
  const startButton = $('#cap-start');
  const langSelect = $('#cap-lang');
  const sizeRange = $('#cap-size');
  const log = $('#cap-log');
  const interim = $('#cap-interim');
  const status = $('#cap-status');
  const lines = []; // { time, text }

  const setStatus = (message) => {
    status.textContent = message;
  };

  sizeRange.addEventListener('input', () => {
    document.documentElement.style.setProperty('--caption-size', `${sizeRange.value}rem`);
  });
  document.documentElement.style.setProperty('--caption-size', `${sizeRange.value}rem`);

  function addLine(textValue) {
    const time = formatTime();
    lines.push({ time, text: textValue });
    log.append(el('p', { class: 'caption-line' }, el('time', { text: time }), textValue));
    log.scrollTop = log.scrollHeight;
  }

  const allText = () => lines.map((l) => `[${l.time}] ${l.text}`).join('\n');

  $('#cap-clear').addEventListener('click', () => {
    lines.length = 0;
    log.replaceChildren();
    interim.textContent = '';
    setStatus('Texto limpo.');
  });

  $('#cap-copy').addEventListener('click', async () => {
    if (!lines.length) {
      setStatus('Ainda não há texto para copiar.');
      return;
    }
    try {
      await navigator.clipboard.writeText(allText());
      setStatus('Texto copiado.');
    } catch {
      const area = el('textarea', { 'aria-hidden': 'true', style: 'position:fixed;opacity:0' });
      area.value = allText();
      document.body.append(area);
      area.select();
      const ok = document.execCommand?.('copy');
      area.remove();
      setStatus(ok ? 'Texto copiado.' : 'Não foi possível copiar. Selecione o texto e copie manualmente.');
    }
  });

  $('#cap-save').addEventListener('click', () => {
    if (!lines.length) {
      setStatus('Ainda não há texto para salvar.');
      return;
    }
    const blob = new Blob([allText()], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = el('a', { href: url, download: `legendas-${new Date().toISOString().slice(0, 10)}.txt` });
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus('Arquivo gerado.');
  });

  if (!SpeechRecognitionApi) {
    $('#cap-unsupported').hidden = false;
    startButton.disabled = true;
    setStatus('Reconhecimento de voz indisponível neste navegador.');
    return;
  }

  let recognition = null;
  let running = false;
  let restartTimer = null;

  function stop(message = 'Legendas paradas.') {
    running = false;
    clearTimeout(restartTimer);
    try {
      recognition?.stop();
    } catch {
      /* já parado */
    }
    interim.textContent = '';
    startButton.textContent = 'Iniciar legendas';
    startButton.setAttribute('aria-pressed', 'false');
    setStatus(message);
  }

  function start() {
    recognition = new SpeechRecognitionApi();
    recognition.lang = langSelect.value;
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onstart = () => setStatus('Ouvindo. Fale perto do microfone.');
    recognition.onresult = (event) => {
      let partial = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const piece = result[0].transcript.trim();
        if (result.isFinal) {
          if (piece) addLine(piece);
        } else {
          partial += `${piece} `;
        }
      }
      interim.textContent = partial.trim();
    };
    recognition.onerror = (event) => {
      if (event.error === 'no-speech' || event.error === 'aborted') return;
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        stop('O acesso ao microfone foi negado. Libere a permissão nas configurações do navegador.');
      } else if (event.error === 'network') {
        stop('Sem conexão com o serviço de reconhecimento de voz. Verifique a internet.');
      } else {
        setStatus(`Erro no reconhecimento de voz (${event.error}).`);
      }
    };
    recognition.onend = () => {
      // O navegador encerra após silêncio; reinicia enquanto a pessoa quiser legendas.
      if (!running) return;
      restartTimer = setTimeout(() => {
        try {
          recognition.start();
        } catch {
          /* já iniciado */
        }
      }, 250);
    };

    running = true;
    startButton.textContent = 'Parar legendas';
    startButton.setAttribute('aria-pressed', 'true');
    try {
      recognition.start();
    } catch {
      stop('Não foi possível iniciar o reconhecimento de voz.');
    }
  }

  startButton.addEventListener('click', () => (running ? stop() : start()));
  langSelect.addEventListener('change', () => {
    if (running) {
      stop('Trocando o idioma…');
      start();
    }
  });
}
