import { $, el } from './ui.js';
import { state, on, emit, signById } from './state.js';
import { api } from './api.js';
import { signCard } from './dictionary.js';

export function initProgress() {
  const stats = $('#stats');
  const favList = $('#fav-list');
  const favEmpty = $('#fav-empty');
  const rows = $('#attempt-rows');

  const stat = (label, value) => el('div', { class: 'stat' }, el('dt', { text: label }), el('dd', { text: String(value) }));

  function bestOf(lessonId) {
    const tries = state.attempts.filter((a) => a.lessonId === lessonId);
    if (!tries.length) return { best: null, count: 0 };
    return { best: tries.reduce((b, a) => (a.score / a.total > b.score / b.total ? a : b)), count: tries.length };
  }

  function render() {
    const summaries = state.lessons.map((lesson) => ({ lesson, ...bestOf(lesson.id) }));
    const practiced = summaries.filter((s) => s.best);
    const average = practiced.length ? Math.round((practiced.reduce((sum, s) => sum + s.best.score / s.best.total, 0) / practiced.length) * 100) : null;

    stats.replaceChildren(
      stat('Sinais favoritos', state.favorites.size),
      stat('Lições praticadas', `${practiced.length} de ${state.lessons.length}`),
      stat('Média das melhores notas', average === null ? '—' : `${average}%`),
      stat('Tentativas', state.attempts.length)
    );

    const favorites = [...state.favorites].map(signById).filter(Boolean).sort((a, b) => a.word.localeCompare(b.word, 'pt-BR'));
    favList.replaceChildren(...favorites.map(signCard));
    favEmpty.hidden = favorites.length > 0;

    rows.replaceChildren(
      ...summaries.map(({ lesson, best, count }) =>
        el('tr', {}, el('th', { scope: 'row', text: lesson.title }), el('td', { text: best ? `${best.score} de ${best.total}` : '—' }), el('td', { text: String(count) }))
      )
    );
  }

  on('progress', render);
  on('favorites', render);
  render();

  // Sugestões
  const form = $('#feedback-form');
  const message = $('#fb-message');
  const contact = $('#fb-contact');
  const fbStatus = $('#fb-status');
  const setFbStatus = (text, kind) => {
    fbStatus.textContent = text;
    fbStatus.className = `form-status${kind ? ` is-${kind}` : ''}`;
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const text = message.value.trim();
    if (text.length < 3) {
      setFbStatus('Escreva uma mensagem com pelo menos 3 letras.', 'error');
      message.focus();
      return;
    }
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      await api.sendFeedback({ message: text, contact: contact.value.trim() || undefined });
      setFbStatus('Obrigado! Sua mensagem foi enviada.', 'ok');
      form.reset();
    } catch {
      setFbStatus('Não foi possível enviar agora. Verifique a conexão com o servidor e tente de novo.', 'error');
    } finally {
      submit.disabled = false;
    }
  });

  // Apagar dados (confirmação em dois toques, sem janelas do navegador)
  const reset = $('#reset-data');
  const resetStatus = $('#reset-status');
  let armed = null;
  reset.addEventListener('click', async () => {
    if (!armed) {
      reset.textContent = 'Toque de novo para confirmar';
      armed = setTimeout(() => {
        armed = null;
        reset.textContent = 'Apagar meus dados';
      }, 5000);
      return;
    }
    clearTimeout(armed);
    armed = null;
    reset.textContent = 'Apagar meus dados';
    const { server } = await api.deleteMyData();
    state.favorites = new Set();
    state.attempts = [];
    emit('favorites', {});
    emit('progress');
    resetStatus.className = 'form-status is-ok';
    resetStatus.textContent = server ? 'Seus dados foram apagados neste aparelho e no servidor.' : 'Seus dados foram apagados neste aparelho. Não foi possível apagar no servidor agora.';
  });
}
