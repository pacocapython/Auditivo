import { $, el, normalize, debounce } from './ui.js';
import { on } from './state.js';

const LETTERS = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'];

// Emojis que lembram a forma da mão, só para letras em que a semelhança é clara.
// São aproximações: o emoji não reproduz o sinal oficial. Para imagens oficiais, use ALPHABET_IMAGE_BASE.
const HAND_HINTS = {
  A: { emoji: '✊', text: 'punho fechado, polegar ao lado' },
  B: { emoji: '✋', text: 'mão aberta, dedos juntos' },
  D: { emoji: '☝️', text: 'indicador para cima' },
  F: { emoji: '👌', text: 'polegar e indicador em círculo' },
  R: { emoji: '🤞', text: 'indicador e médio cruzados' },
  V: { emoji: '✌️', text: 'indicador e médio em V' },
  Y: { emoji: '🤙', text: 'polegar e mínimo estendidos' }
};

export function initAlphabet() {
  const input = $('#spell-input');
  const stage = $('#spell-stage');
  const count = $('#spell-count');
  const tiles = $('#spell-tiles');
  const prev = $('#spell-prev');
  const next = $('#spell-next');
  const play = $('#spell-play');
  const speed = $('#spell-speed');
  const grid = $('#alpha-grid');
  const imageBase = window.APP_CONFIG?.ALPHABET_IMAGE_BASE;

  let chars = []; // letras e espaços da palavra
  let letterPositions = []; // índices de `chars` que são letras
  let pos = 0; // posição atual dentro de letterPositions
  let timer = null;

  function showLetter(letter) {
    stage.replaceChildren();
    if (imageBase) {
      stage.append(
        el('img', {
          src: `${imageBase}/${letter}.png`,
          alt: '',
          onerror: (event) => {
            event.currentTarget.remove();
            stage.textContent = letter;
          }
        })
      );
    } else {
      const hint = HAND_HINTS[letter];
      stage.replaceChildren(
        el('span', { text: letter }),
        hint ? el('span', { class: 'hand-emoji', text: hint.emoji }) : null,
        hint ? el('span', { class: 'hand-text', text: `Mão aproximada: ${hint.text}` }) : el('span', { class: 'hand-text', text: 'Sem emoji parecido. Veja o sinal em vídeo ou com um instrutor.' })
      );
    }
  }

  function renderTiles() {
    tiles.replaceChildren(
      ...chars.map((char, index) => {
        if (char === ' ') return el('li', { class: 'tile-gap', 'aria-hidden': 'true' });
        const step = letterPositions.indexOf(index);
        return el(
          'li',
          {},
          el('button', {
            type: 'button',
            class: 'tile',
            'data-step': String(step),
            'aria-label': `Letra ${char}, ${step + 1} de ${letterPositions.length}`,
            text: char,
            onclick: () => {
              stopPlay();
              pos = step;
              update();
            }
          })
        );
      })
    );
  }

  function update() {
    const has = letterPositions.length > 0;
    prev.disabled = !has || pos === 0;
    next.disabled = !has || pos >= letterPositions.length - 1;
    play.disabled = !has;
    if (!has) {
      stage.textContent = '?';
      count.textContent = 'Digite uma palavra para começar.';
      return;
    }
    const letter = chars[letterPositions[pos]];
    showLetter(letter);
    count.textContent = `Letra ${letter}, ${pos + 1} de ${letterPositions.length}`;
    tiles.querySelectorAll('.tile').forEach((tile) => {
      if (Number(tile.dataset.step) === pos) tile.setAttribute('aria-current', 'true');
      else tile.removeAttribute('aria-current');
    });
  }

  function stopPlay() {
    clearInterval(timer);
    timer = null;
    play.setAttribute('aria-pressed', 'false');
    play.textContent = 'Reproduzir soletração';
  }

  function startPlay() {
    if (!letterPositions.length) return;
    if (pos >= letterPositions.length - 1) pos = 0;
    update();
    play.setAttribute('aria-pressed', 'true');
    play.textContent = 'Pausar';
    timer = setInterval(() => {
      if (pos >= letterPositions.length - 1) {
        stopPlay();
        return;
      }
      pos += 1;
      update();
    }, Number(speed.value));
  }

  function parse() {
    stopPlay();
    chars = [...normalize(input.value).replace(/\s+/g, ' ')].filter((c) => /[a-z ]/.test(c)).map((c) => c.toUpperCase());
    letterPositions = chars.map((c, i) => (c === ' ' ? -1 : i)).filter((i) => i >= 0);
    pos = 0;
    renderTiles();
    update();
  }

  input.addEventListener('input', debounce(parse, 150));
  $('#spell-form').addEventListener('submit', (event) => event.preventDefault());
  prev.addEventListener('click', () => {
    stopPlay();
    pos = Math.max(0, pos - 1);
    update();
  });
  next.addEventListener('click', () => {
    stopPlay();
    pos = Math.min(letterPositions.length - 1, pos + 1);
    update();
  });
  play.addEventListener('click', () => (timer ? stopPlay() : startPlay()));
  speed.addEventListener('change', () => {
    if (timer) {
      stopPlay();
      startPlay();
    }
  });

  grid.replaceChildren(
    ...LETTERS.map((letter) =>
      el(
        'li',
        {},
        el('button', {
          type: 'button',
          class: 'tile',
          'aria-label': `Mostrar a letra ${letter}`,
          text: HAND_HINTS[letter] ? `${letter} ${HAND_HINTS[letter].emoji}` : letter,
          onclick: () => {
            stopPlay();
            showLetter(letter);
            count.textContent = `Letra ${letter} do alfabeto`;
            tiles.querySelectorAll('.tile').forEach((tile) => tile.removeAttribute('aria-current'));
            stage.scrollIntoView?.({ block: 'center' });
          }
        })
      )
    )
  );

  // Vindo do dicionário: "Ver soletração"
  on('spell', (word) => {
    input.value = word;
    parse();
  });

  update();
}
