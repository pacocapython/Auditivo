import { OFFLINE_DATA } from './data.js';
import { storage, getUserId } from './storage.js';

const TIMEOUT_MS = 6000;

/**
 * Cliente da API. Se o servidor não responder, o app continua funcionando
 * com os dados de exemplo e guarda favoritos e pontuações no aparelho.
 */
export const api = {
  baseUrl: (window.APP_CONFIG && window.APP_CONFIG.API_URL) || '',
  online: false,
  userId: getUserId(),

  async request(path, { method = 'GET', body } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(this.baseUrl + path, {
        method,
        signal: controller.signal,
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: body ? JSON.stringify(body) : undefined
      });
      if (!response.ok) {
        const error = new Error(`HTTP ${response.status}`);
        error.status = response.status;
        throw error;
      }
      this.online = true;
      return response.status === 204 ? null : await response.json();
    } catch (error) {
      if (!error.status) this.online = false; // erro de rede, não de validação
      throw error;
    } finally {
      clearTimeout(timer);
    }
  },

  async loadCatalog() {
    // Aberto como arquivo local (duplo clique) e sem API_URL: não há servidor para chamar.
    if (!this.baseUrl && location.protocol === 'file:') {
      this.online = false;
      return { ...OFFLINE_DATA, source: 'offline' };
    }
    try {
      const [categories, signs, lessons, phrases] = await Promise.all([
        this.request('/api/categories'),
        this.request('/api/signs'),
        this.request('/api/lessons'),
        this.request('/api/phrases')
      ]);
      if (![categories, signs, lessons, phrases].every(Array.isArray)) throw new Error('Resposta inesperada');
      return { categories, signs, lessons, phrases, source: 'server' };
    } catch {
      this.online = false;
      return { ...OFFLINE_DATA, source: 'offline' };
    }
  },

  async loadFavorites() {
    const local = storage.get('favorites', []);
    if (!this.online) return local;
    try {
      const remote = await this.request(`/api/users/${this.userId}/favorites`);
      const merged = [...new Set([...remote, ...local])];
      storage.set('favorites', merged);
      // envia ao servidor o que só existia no aparelho
      for (const id of local.filter((x) => !remote.includes(x))) {
        this.request(`/api/users/${this.userId}/favorites/${encodeURIComponent(id)}`, { method: 'PUT' }).catch(() => {});
      }
      return merged;
    } catch {
      return local;
    }
  },

  async setFavorite(signId, isFavorite) {
    const list = new Set(storage.get('favorites', []));
    if (isFavorite) list.add(signId);
    else list.delete(signId);
    storage.set('favorites', [...list]);
    if (!this.online) return;
    try {
      await this.request(`/api/users/${this.userId}/favorites/${encodeURIComponent(signId)}`, {
        method: isFavorite ? 'PUT' : 'DELETE'
      });
    } catch {
      /* fica salvo no aparelho e sincroniza na próxima abertura */
    }
  },

  async saveAttempt({ lessonId, score, total }) {
    const record = { lessonId, score, total, createdAt: new Date().toISOString() };
    const local = storage.get('attempts', []);
    local.push(record);
    storage.set('attempts', local.slice(-200));
    if (this.online) {
      try {
        await this.request(`/api/users/${this.userId}/attempts`, { method: 'POST', body: { lessonId, score, total } });
      } catch {
        /* mantém só no aparelho */
      }
    }
    return record;
  },

  async loadAttempts() {
    const local = [...storage.get('attempts', [])].reverse();
    if (!this.online) return local;
    try {
      const remote = await this.request(`/api/users/${this.userId}/attempts`);
      return remote.length >= local.length ? remote : local;
    } catch {
      return local;
    }
  },

  async sendFeedback({ message, contact }) {
    return this.request('/api/feedback', { method: 'POST', body: { userId: this.userId, message, contact } });
  },

  /** Apaga favoritos e pontuações no aparelho e, se possível, no servidor. */
  async deleteMyData() {
    storage.remove('favorites');
    storage.remove('attempts');
    if (!this.online) return { server: false };
    try {
      await this.request(`/api/users/${this.userId}`, { method: 'DELETE' });
      return { server: true };
    } catch {
      return { server: false };
    }
  }
};
