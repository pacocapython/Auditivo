import { $ } from './ui.js';
import { api } from './api.js';
import { state } from './state.js';
import { initA11y } from './a11y.js';
import { initRouter } from './router.js';
import { initDictionary } from './dictionary.js';
import { initAlphabet } from './alphabet.js';
import { initLearn } from './learn.js';
import { initCommunicate } from './communicate.js';
import { initCaptions } from './captions.js';
import { initSoundAlert } from './soundalert.js';
import { initProgress } from './progress.js';

function updateNetStatus() {
  const chip = $('#net-status');
  const connected = state.source === 'server';
  chip.textContent = connected ? 'Conectado ao servidor' : 'Modo offline (dados do aparelho)';
  chip.classList.toggle('is-ok', connected);
  chip.classList.toggle('is-warn', !connected);
}

async function boot() {
  initA11y();

  const catalog = await api.loadCatalog();
  Object.assign(state, {
    categories: catalog.categories,
    signs: catalog.signs,
    lessons: catalog.lessons,
    phrases: catalog.phrases,
    source: catalog.source
  });
  state.favorites = new Set(await api.loadFavorites());
  state.attempts = await api.loadAttempts();
  updateNetStatus();

  initDictionary();
  initAlphabet();
  initLearn();
  initCommunicate();
  initCaptions();
  initSoundAlert();
  initProgress();
  initRouter();

  if ('serviceWorker' in navigator && window.APP_CONFIG?.PWA !== false && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

boot();
