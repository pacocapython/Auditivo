// Armazenamento local seguro: se o navegador bloquear o localStorage, usa a memória.
const mem = new Map();
const PREFIX = 'libras-acesso:';

export const storage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) return JSON.parse(raw);
    } catch {
      /* armazenamento indisponível */
    }
    return mem.has(key) ? mem.get(key) : fallback;
  },
  set(key, value) {
    mem.set(key, value);
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch {
      /* armazenamento indisponível */
    }
  },
  remove(key) {
    mem.delete(key);
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {
      /* armazenamento indisponível */
    }
  }
};

/** Código anônimo deste aparelho (não identifica a pessoa). */
export function getUserId() {
  let id = storage.get('userId');
  if (!id) {
    id = crypto.randomUUID ? crypto.randomUUID() : `u-${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
    storage.set('userId', id);
  }
  return id;
}
