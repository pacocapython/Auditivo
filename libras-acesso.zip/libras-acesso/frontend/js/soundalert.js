import { $, el, formatTime, vibrate, prefersReducedMotion } from './ui.js';

let toastTimer;

/** Aviso visual grande, tela piscando (suave) e vibração. */
export function fireAlert(message) {
  const toast = $('#alert-toast');
  toast.textContent = message;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.hidden = true;
  }, 7000);

  const flash = $('#flash');
  if (!prefersReducedMotion() && document.documentElement.dataset.flash !== 'off') {
    flash.classList.remove('on');
    void flash.offsetWidth; // reinicia a animação
    flash.classList.add('on');
  }
  vibrate([300, 120, 300, 120, 300]);
}

export function initSoundAlert() {
  const startButton = $('#snd-start');
  const testButton = $('#snd-test');
  const range = $('#snd-threshold');
  const rangeOut = $('#snd-threshold-out');
  const meter = $('#snd-meter');
  const fill = $('#snd-fill');
  const mark = $('#snd-mark');
  const status = $('#snd-status');
  const history = $('#snd-history');
  const chip = $('#alert-chip');

  let stream = null;
  let audioContext = null;
  let analyser = null;
  let samples = null;
  let timer = null;
  let lastFire = 0;
  let lastAria = 0;
  let eventCount = 0;
  let threshold = Number(range.value);

  const setStatus = (message) => {
    status.textContent = message;
  };

  function syncThreshold() {
    threshold = Number(range.value);
    mark.style.left = `${threshold}%`;
    rangeOut.textContent = `${threshold}%`;
  }
  syncThreshold();
  range.addEventListener('input', syncThreshold);

  $('#flash').addEventListener('animationend', (event) => event.currentTarget.classList.remove('on'));

  function addHistory(message) {
    if (eventCount === 0) history.replaceChildren();
    eventCount += 1;
    history.prepend(el('li', { text: `${formatTime()}: ${message}` }));
    while (history.children.length > 20) history.lastChild.remove();
  }

  function sample() {
    analyser.getByteTimeDomainData(samples);
    let sum = 0;
    for (let i = 0; i < samples.length; i++) {
      const v = (samples[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / samples.length);
    const db = 20 * Math.log10(Math.max(rms, 1e-5));
    const level = Math.max(0, Math.min(100, Math.round(((db + 60) / 60) * 100))); // -60 dB = 0%, 0 dB = 100%
    fill.style.width = `${level}%`;

    const now = Date.now();
    if (now - lastAria > 500) {
      meter.setAttribute('aria-valuenow', String(level));
      lastAria = now;
    }
    if (level >= threshold && now - lastFire > 3000) {
      lastFire = now;
      const message = `Som alto detectado às ${formatTime()}`;
      fireAlert(message);
      addHistory('som alto detectado.');
    }
  }

  async function start() {
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus('Este navegador não permite usar o microfone. No celular, abra o app por uma conexão segura (https).');
      return;
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
      });
    } catch (error) {
      setStatus(
        error?.name === 'NotAllowedError'
          ? 'O acesso ao microfone foi negado. Libere a permissão nas configurações do navegador.'
          : 'Não foi possível acessar o microfone.'
      );
      return;
    }
    const AudioContextApi = window.AudioContext || window.webkitAudioContext;
    audioContext = new AudioContextApi();
    if (audioContext.state === 'suspended') await audioContext.resume();
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 1024;
    audioContext.createMediaStreamSource(stream).connect(analyser);
    samples = new Uint8Array(analyser.fftSize);

    timer = setInterval(sample, 100);
    startButton.textContent = 'Desativar alerta';
    startButton.setAttribute('aria-pressed', 'true');
    chip.hidden = false;
    setStatus('Alerta ativo. Mantenha esta página aberta e a tela ligada.');
  }

  function stop() {
    clearInterval(timer);
    timer = null;
    stream?.getTracks().forEach((track) => track.stop());
    audioContext?.close?.();
    stream = null;
    audioContext = null;
    fill.style.width = '0%';
    meter.setAttribute('aria-valuenow', '0');
    startButton.textContent = 'Ativar alerta';
    startButton.setAttribute('aria-pressed', 'false');
    chip.hidden = true;
    setStatus('O alerta está desligado.');
  }

  startButton.addEventListener('click', () => (timer ? stop() : start()));
  testButton.addEventListener('click', () => {
    fireAlert('Teste: assim será o aviso de som.');
    addHistory('teste do aviso.');
  });
}
