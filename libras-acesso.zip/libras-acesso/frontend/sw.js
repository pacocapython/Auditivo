// Service worker: guarda os arquivos do app para abrir offline.
// A API não é guardada aqui; o app já tem dados de exemplo e salva favoritos/pontuação no aparelho.
const CACHE = 'libras-acesso-v1';
const ASSETS = [
  './', 'index.html', 'config.js', 'manifest.webmanifest', 'icon.svg', 'css/styles.css',
  'js/app.js', 'js/storage.js', 'js/ui.js', 'js/data.js', 'js/api.js', 'js/state.js', 'js/a11y.js',
  'js/router.js', 'js/dictionary.js', 'js/alphabet.js', 'js/learn.js', 'js/communicate.js',
  'js/captions.js', 'js/soundalert.js', 'js/progress.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;

  // Rede primeiro (conteúdo sempre atualizado), cache como reserva offline.
  event.respondWith(
    fetch(request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE).then((cache) => cache.put(request, copy));
        return response;
      })
      .catch(() => caches.match(request).then((hit) => hit || caches.match('index.html')))
  );
});
