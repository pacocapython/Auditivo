import mysql from 'mysql2/promise';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { normalize } from '../../data/seed.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const SCHEMA_FILE = path.join(here, '../../sql/mysql_schema.sql');

const escapeLike = (text) => text.replace(/[\\%_]/g, (c) => `\\${c}`);

function buildConfig(env) {
  const url = env.DATABASE_URL || env.MYSQL_URL;
  let cfg;
  if (url) {
    const u = new URL(url);
    cfg = {
      host: u.hostname,
      port: Number(u.port || 3306),
      user: decodeURIComponent(u.username),
      password: decodeURIComponent(u.password),
      database: decodeURIComponent(u.pathname.slice(1))
    };
  } else {
    cfg = {
      host: env.MYSQL_HOST,
      port: Number(env.MYSQL_PORT || 3306),
      user: env.MYSQL_USER,
      password: env.MYSQL_PASSWORD,
      database: env.MYSQL_DATABASE
    };
  }
  if (!cfg.host || !cfg.user || !cfg.database) {
    throw new Error('MySQL não configurado: defina DATABASE_URL ou MYSQL_HOST/MYSQL_USER/MYSQL_DATABASE.');
  }
  return {
    ...cfg,
    charset: 'utf8mb4',
    ...(String(env.MYSQL_SSL).toLowerCase() === 'true' ? { ssl: { rejectUnauthorized: true } } : {})
  };
}

const SIGN_COLUMNS = `id, word, category_id AS category, emoji, description, tip,
  video_url AS videoUrl, image_url AS imageUrl, validated`;

const toSign = (row) => ({ ...row, validated: Boolean(row.validated) });

export class MySqlRepository {
  provider = 'mysql';

  constructor(env) {
    this.config = buildConfig(env);
    this.pool = mysql.createPool({
      ...this.config,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
  }

  async ping() {
    await this.pool.query('SELECT 1');
    return true;
  }

  /** Cria as tabelas (idempotente). Usado pelo script de seed. */
  async migrate() {
    const sql = await readFile(SCHEMA_FILE, 'utf8');
    const conn = await mysql.createConnection({ ...this.config, multipleStatements: true });
    try {
      await conn.query(sql);
    } finally {
      await conn.end();
    }
  }

  async listCategories() {
    const [rows] = await this.pool.query('SELECT id, name, icon FROM categories ORDER BY sort_order');
    return rows;
  }

  async listSigns({ q, category, limit = 200 } = {}) {
    const where = [];
    const params = [];
    if (category) {
      where.push('category_id = ?');
      params.push(category);
    }
    const term = normalize(q);
    if (term) {
      where.push('search_text LIKE ?');
      params.push(`%${escapeLike(term)}%`);
    }
    const sql = `SELECT ${SIGN_COLUMNS} FROM signs ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
                 ORDER BY word LIMIT ?`;
    const [rows] = await this.pool.query(sql, [...params, Number(limit)]);
    return rows.map(toSign);
  }

  async getSign(id) {
    const [rows] = await this.pool.query(`SELECT ${SIGN_COLUMNS} FROM signs WHERE id = ? LIMIT 1`, [id]);
    return rows[0] ? toSign(rows[0]) : null;
  }

  async listLessons() {
    const [lessons] = await this.pool.query('SELECT id, title, description FROM lessons ORDER BY sort_order');
    const [links] = await this.pool.query('SELECT lesson_id, sign_id FROM lesson_signs ORDER BY lesson_id, position');
    const byLesson = new Map();
    for (const { lesson_id, sign_id } of links) {
      if (!byLesson.has(lesson_id)) byLesson.set(lesson_id, []);
      byLesson.get(lesson_id).push(sign_id);
    }
    return lessons.map((l) => ({ ...l, signIds: byLesson.get(l.id) ?? [] }));
  }

  async listPhrases() {
    const [rows] = await this.pool.query('SELECT id, text, category, urgent FROM phrases ORDER BY sort_order');
    return rows.map((r) => ({ ...r, urgent: Boolean(r.urgent) }));
  }

  async listFavorites(userId) {
    const [rows] = await this.pool.query('SELECT sign_id FROM favorites WHERE user_id = ? ORDER BY created_at', [userId]);
    return rows.map((r) => r.sign_id);
  }

  async addFavorite(userId, signId) {
    await this.pool.query('INSERT IGNORE INTO favorites (user_id, sign_id) VALUES (?, ?)', [userId, signId]);
  }

  async removeFavorite(userId, signId) {
    await this.pool.query('DELETE FROM favorites WHERE user_id = ? AND sign_id = ?', [userId, signId]);
  }

  async listAttempts(userId) {
    const [rows] = await this.pool.query(
      `SELECT lesson_id AS lessonId, score, total, created_at AS createdAt
       FROM attempts WHERE user_id = ? ORDER BY id DESC LIMIT 100`,
      [userId]
    );
    return rows.map((r) => ({ ...r, createdAt: new Date(r.createdAt).toISOString() }));
  }

  async saveAttempt(userId, { lessonId, score, total }) {
    await this.pool.query('INSERT INTO attempts (user_id, lesson_id, score, total) VALUES (?, ?, ?, ?)', [
      userId,
      lessonId,
      score,
      total
    ]);
  }

  async deleteUserData(userId) {
    await this.pool.query('DELETE FROM favorites WHERE user_id = ?', [userId]);
    await this.pool.query('DELETE FROM attempts WHERE user_id = ?', [userId]);
  }

  async addFeedback({ userId, message, contact }) {
    await this.pool.query('INSERT INTO feedback (user_id, message, contact) VALUES (?, ?, ?)', [
      userId ?? null,
      message,
      contact ?? null
    ]);
  }

  /** Carrega o conteúdo inicial (categorias, sinais, lições e frases). */
  async seed(data) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();

      await conn.query(
        `INSERT INTO categories (id, name, icon, sort_order) VALUES ?
         ON DUPLICATE KEY UPDATE name = VALUES(name), icon = VALUES(icon), sort_order = VALUES(sort_order)`,
        [data.categories.map((c) => [c.id, c.name, c.icon, c.sortOrder])]
      );

      await conn.query(
        `INSERT INTO signs (id, word, category_id, emoji, description, tip, video_url, image_url, validated, search_text) VALUES ?
         ON DUPLICATE KEY UPDATE word = VALUES(word), category_id = VALUES(category_id), emoji = VALUES(emoji),
           description = VALUES(description), tip = VALUES(tip), search_text = VALUES(search_text)`,
        [data.signs.map((s) => [s.id, s.word, s.category, s.emoji, s.description, s.tip, s.videoUrl, s.imageUrl, s.validated ? 1 : 0, s.searchText])]
      );

      await conn.query(
        `INSERT INTO lessons (id, title, description, sort_order) VALUES ?
         ON DUPLICATE KEY UPDATE title = VALUES(title), description = VALUES(description), sort_order = VALUES(sort_order)`,
        [data.lessons.map((l) => [l.id, l.title, l.description, l.sortOrder])]
      );

      await conn.query('DELETE FROM lesson_signs');
      const links = data.lessons.flatMap((l) => l.signIds.map((signId, i) => [l.id, signId, i + 1]));
      await conn.query('INSERT INTO lesson_signs (lesson_id, sign_id, position) VALUES ?', [links]);

      await conn.query(
        `INSERT INTO phrases (id, text, category, urgent, sort_order) VALUES ?
         ON DUPLICATE KEY UPDATE text = VALUES(text), category = VALUES(category), urgent = VALUES(urgent), sort_order = VALUES(sort_order)`,
        [data.phrases.map((p, i) => [p.id, p.text, p.category, p.urgent ? 1 : 0, i + 1])]
      );

      await conn.commit();
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  }
}
