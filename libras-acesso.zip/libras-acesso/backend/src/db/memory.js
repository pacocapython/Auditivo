import { loadSeed, normalize } from '../../data/seed.js';

const publicSign = ({ searchText, ...sign }) => sign;

/** Repositório em memória: ótimo para desenvolvimento e testes. Os dados somem ao reiniciar. */
export class MemoryRepository {
  provider = 'memory';

  constructor() {
    this.data = loadSeed();
    this.favorites = new Map(); // userId -> Set(signId)
    this.attempts = []; // { userId, lessonId, score, total, createdAt }
    this.feedback = [];
  }

  async ping() {
    return true;
  }

  async listCategories() {
    return [...this.data.categories].sort((a, b) => a.sortOrder - b.sortOrder).map(({ sortOrder, ...c }) => c);
  }

  async listSigns({ q, category, limit = 200 } = {}) {
    const term = normalize(q);
    return this.data.signs
      .filter((s) => (!category || s.category === category) && (!term || s.searchText.includes(term)))
      .sort((a, b) => a.word.localeCompare(b.word, 'pt-BR'))
      .slice(0, limit)
      .map(publicSign);
  }

  async getSign(id) {
    const sign = this.data.signs.find((s) => s.id === id);
    return sign ? publicSign(sign) : null;
  }

  async listLessons() {
    return [...this.data.lessons].sort((a, b) => a.sortOrder - b.sortOrder).map(({ sortOrder, ...l }) => l);
  }

  async listPhrases() {
    return this.data.phrases;
  }

  async listFavorites(userId) {
    return [...(this.favorites.get(userId) ?? [])];
  }

  async addFavorite(userId, signId) {
    if (!this.favorites.has(userId)) this.favorites.set(userId, new Set());
    this.favorites.get(userId).add(signId);
  }

  async removeFavorite(userId, signId) {
    this.favorites.get(userId)?.delete(signId);
  }

  async listAttempts(userId) {
    return this.attempts
      .filter((a) => a.userId === userId)
      .slice(-100)
      .reverse()
      .map(({ userId: _u, ...a }) => a);
  }

  async saveAttempt(userId, { lessonId, score, total }) {
    this.attempts.push({ userId, lessonId, score, total, createdAt: new Date().toISOString() });
  }

  async deleteUserData(userId) {
    this.favorites.delete(userId);
    this.attempts = this.attempts.filter((a) => a.userId !== userId);
  }

  async addFeedback({ userId, message, contact }) {
    this.feedback.push({ userId, message, contact, createdAt: new Date().toISOString() });
  }

  async seed() {
    this.data = loadSeed();
  }
}
