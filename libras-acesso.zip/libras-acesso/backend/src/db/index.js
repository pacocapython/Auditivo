/**
 * Escolhe o repositório de dados conforme DB_PROVIDER.
 * Todos os repositórios expõem a mesma interface assíncrona:
 *
 *   ping(), listCategories(), listSigns({ q, category, limit }), getSign(id),
 *   listLessons(), listPhrases(),
 *   listFavorites(userId), addFavorite(userId, signId), removeFavorite(userId, signId),
 *   listAttempts(userId), saveAttempt(userId, { lessonId, score, total }),
 *   addFeedback({ userId, message, contact }), seed(data)
 */
export async function createRepository(env = process.env) {
  const provider = (env.DB_PROVIDER || 'memory').toLowerCase();

  switch (provider) {
    case 'memory': {
      const { MemoryRepository } = await import('./memory.js');
      return new MemoryRepository();
    }
    case 'mysql': {
      const { MySqlRepository } = await import('./mysql.js');
      return new MySqlRepository(env);
    }
    case 'supabase': {
      const { SupabaseRepository } = await import('./supabase.js');
      return new SupabaseRepository(env);
    }
    default:
      throw new Error(`DB_PROVIDER inválido: "${provider}". Use memory, mysql ou supabase.`);
  }
}
