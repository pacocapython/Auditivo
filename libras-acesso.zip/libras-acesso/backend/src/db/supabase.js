import { createClient } from '@supabase/supabase-js';
import { normalize } from '../../data/seed.js';

const SIGN_COLUMNS = 'id, word, category_id, emoji, description, tip, video_url, image_url, validated';

const toSign = (row) => ({
  id: row.id,
  word: row.word,
  category: row.category_id,
  emoji: row.emoji,
  description: row.description,
  tip: row.tip,
  videoUrl: row.video_url,
  imageUrl: row.image_url,
  validated: Boolean(row.validated)
});

/** Remove caracteres com significado especial em filtros do PostgREST e curingas do LIKE. */
const sanitizeTerm = (text) => normalize(text).replace(/[%_*,()\\"']/g, ' ').replace(/\s+/g, ' ').trim();

function check({ data, error }) {
  if (error) throw new Error(`Supabase: ${error.message}`);
  return data;
}

/**
 * Repositório Supabase (Postgres). Usa a service_role key, portanto roda só no servidor.
 * As tabelas de usuário (favorites, attempts, feedback) têm RLS ligado e nenhuma policy pública:
 * só o servidor consegue lê-las ou gravá-las.
 */
export class SupabaseRepository {
  provider = 'supabase';

  constructor(env) {
    if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Supabase não configurado: defina SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY.');
    }
    this.db = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    });
  }

  async ping() {
    check(await this.db.from('categories').select('id').limit(1));
    return true;
  }

  async listCategories() {
    return check(await this.db.from('categories').select('id, name, icon').order('sort_order'));
  }

  async listSigns({ q, category, limit = 200 } = {}) {
    let query = this.db.from('signs').select(SIGN_COLUMNS).order('word').limit(Number(limit));
    if (category) query = query.eq('category_id', category);
    const term = sanitizeTerm(q);
    if (term) query = query.ilike('search_text', `%${term}%`);
    return check(await query).map(toSign);
  }

  async getSign(id) {
    const row = check(await this.db.from('signs').select(SIGN_COLUMNS).eq('id', id).maybeSingle());
    return row ? toSign(row) : null;
  }

  async listLessons() {
    const rows = check(
      await this.db.from('lessons').select('id, title, description, sort_order, lesson_signs(sign_id, position)').order('sort_order')
    );
    return rows.map((l) => ({
      id: l.id,
      title: l.title,
      description: l.description,
      signIds: [...l.lesson_signs].sort((a, b) => a.position - b.position).map((x) => x.sign_id)
    }));
  }

  async listPhrases() {
    return check(await this.db.from('phrases').select('id, text, category, urgent').order('sort_order'));
  }

  async listFavorites(userId) {
    const rows = check(await this.db.from('favorites').select('sign_id').eq('user_id', userId).order('created_at'));
    return rows.map((r) => r.sign_id);
  }

  async addFavorite(userId, signId) {
    check(
      await this.db
        .from('favorites')
        .upsert({ user_id: userId, sign_id: signId }, { onConflict: 'user_id,sign_id', ignoreDuplicates: true })
    );
  }

  async removeFavorite(userId, signId) {
    check(await this.db.from('favorites').delete().eq('user_id', userId).eq('sign_id', signId));
  }

  async listAttempts(userId) {
    const rows = check(
      await this.db
        .from('attempts')
        .select('lesson_id, score, total, created_at')
        .eq('user_id', userId)
        .order('id', { ascending: false })
        .limit(100)
    );
    return rows.map((r) => ({ lessonId: r.lesson_id, score: r.score, total: r.total, createdAt: r.created_at }));
  }

  async saveAttempt(userId, { lessonId, score, total }) {
    check(await this.db.from('attempts').insert({ user_id: userId, lesson_id: lessonId, score, total }));
  }

  async deleteUserData(userId) {
    check(await this.db.from('favorites').delete().eq('user_id', userId));
    check(await this.db.from('attempts').delete().eq('user_id', userId));
  }

  async addFeedback({ userId, message, contact }) {
    check(await this.db.from('feedback').insert({ user_id: userId ?? null, message, contact: contact ?? null }));
  }

  /** Carrega o conteúdo inicial. As tabelas precisam existir (rode sql/supabase_schema.sql antes). */
  async seed(data) {
    check(
      await this.db
        .from('categories')
        .upsert(data.categories.map((c) => ({ id: c.id, name: c.name, icon: c.icon, sort_order: c.sortOrder })))
    );

    check(
      await this.db.from('signs').upsert(
        data.signs.map((s) => ({
          id: s.id,
          word: s.word,
          category_id: s.category,
          emoji: s.emoji,
          description: s.description,
          tip: s.tip,
          video_url: s.videoUrl,
          image_url: s.imageUrl,
          validated: s.validated,
          search_text: s.searchText
        }))
      )
    );

    check(
      await this.db
        .from('lessons')
        .upsert(data.lessons.map((l) => ({ id: l.id, title: l.title, description: l.description, sort_order: l.sortOrder })))
    );

    check(await this.db.from('lesson_signs').delete().neq('lesson_id', ''));
    const links = data.lessons.flatMap((l) => l.signIds.map((signId, i) => ({ lesson_id: l.id, sign_id: signId, position: i + 1 })));
    check(await this.db.from('lesson_signs').insert(links));

    check(
      await this.db
        .from('phrases')
        .upsert(data.phrases.map((p, i) => ({ id: p.id, text: p.text, category: p.category, urgent: p.urgent, sort_order: i + 1 })))
    );
  }
}
