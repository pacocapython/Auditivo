import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Identificadores: letras, números e hífen (UUID, slugs dos sinais etc.)
const userIdSchema = z.string().regex(/^[a-zA-Z0-9-]{8,64}$/, 'Identificador de usuário inválido.');
const slugSchema = z.string().regex(/^[a-z0-9-]{1,60}$/, 'Identificador inválido.');

const attemptSchema = z
  .object({
    lessonId: slugSchema,
    score: z.number().int().min(0).max(100),
    total: z.number().int().min(1).max(100)
  })
  .refine((a) => a.score <= a.total, { message: 'A pontuação não pode ser maior que o total.' });

const feedbackSchema = z.object({
  userId: userIdSchema.optional(),
  message: z.string().trim().min(3, 'Escreva uma mensagem.').max(1000, 'Mensagem muito longa (máx. 1000 caracteres).'),
  contact: z.string().trim().max(200).optional()
});

const signsQuerySchema = z.object({
  q: z.string().trim().max(80).optional(),
  category: slugSchema.optional(),
  limit: z.coerce.number().int().min(1).max(500).optional()
});

class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

function parse(schema, value) {
  const result = schema.safeParse(value);
  if (!result.success) {
    const details = result.error.issues.map((i) => i.message);
    throw new HttpError(400, details[0] ?? 'Dados inválidos.', details);
  }
  return result.data;
}

export function buildRouter(repo) {
  const router = Router();

  const feedbackLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    limit: 10,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Muitos envios. Tente novamente mais tarde.' }
  });

  router.get(
    '/health',
    asyncHandler(async (_req, res) => {
      let database = 'ok';
      try {
        await repo.ping();
      } catch {
        database = 'erro';
      }
      res.status(database === 'ok' ? 200 : 503).json({ status: database === 'ok' ? 'ok' : 'degradado', provider: repo.provider, database });
    })
  );

  router.get('/categories', asyncHandler(async (_req, res) => res.json(await repo.listCategories())));

  router.get(
    '/signs',
    asyncHandler(async (req, res) => {
      const query = parse(signsQuerySchema, req.query);
      res.json(await repo.listSigns(query));
    })
  );

  router.get(
    '/signs/:id',
    asyncHandler(async (req, res) => {
      const id = parse(slugSchema, req.params.id);
      const sign = await repo.getSign(id);
      if (!sign) throw new HttpError(404, 'Sinal não encontrado.');
      res.json(sign);
    })
  );

  router.get('/lessons', asyncHandler(async (_req, res) => res.json(await repo.listLessons())));
  router.get('/phrases', asyncHandler(async (_req, res) => res.json(await repo.listPhrases())));

  // --- Dados do usuário (identificador anônimo) -----------------
  router.get(
    '/users/:userId/favorites',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      res.json(await repo.listFavorites(userId));
    })
  );

  router.put(
    '/users/:userId/favorites/:signId',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      const signId = parse(slugSchema, req.params.signId);
      if (!(await repo.getSign(signId))) throw new HttpError(404, 'Sinal não encontrado.');
      await repo.addFavorite(userId, signId);
      res.status(204).end();
    })
  );

  router.delete(
    '/users/:userId/favorites/:signId',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      const signId = parse(slugSchema, req.params.signId);
      await repo.removeFavorite(userId, signId);
      res.status(204).end();
    })
  );

  router.get(
    '/users/:userId/attempts',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      res.json(await repo.listAttempts(userId));
    })
  );

  router.post(
    '/users/:userId/attempts',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      const attempt = parse(attemptSchema, req.body);
      const lessons = await repo.listLessons();
      if (!lessons.some((l) => l.id === attempt.lessonId)) throw new HttpError(404, 'Lição não encontrada.');
      await repo.saveAttempt(userId, attempt);
      res.status(201).json({ ok: true });
    })
  );

  // Direito de exclusão (LGPD): apaga favoritos e pontuações do código anônimo.
  router.delete(
    '/users/:userId',
    asyncHandler(async (req, res) => {
      const userId = parse(userIdSchema, req.params.userId);
      await repo.deleteUserData(userId);
      res.status(204).end();
    })
  );

  router.post(
    '/feedback',
    feedbackLimiter,
    asyncHandler(async (req, res) => {
      const data = parse(feedbackSchema, req.body);
      await repo.addFeedback(data);
      res.status(201).json({ ok: true });
    })
  );

  return router;
}

export { HttpError };
