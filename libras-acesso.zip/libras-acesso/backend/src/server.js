import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRepository } from './db/index.js';
import { buildRouter, HttpError } from './routes.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const FRONTEND_DIR = path.resolve(here, '../../frontend');

export async function createApp(env = process.env) {
  const repo = await createRepository(env);
  const app = express();

  // Atrás do proxy do Render: necessário para o rate limit enxergar o IP real.
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'https:'],
          mediaSrc: ["'self'", 'https:'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          frameAncestors: ["'self'"]
        }
      },
      // O microfone é usado pelas legendas ao vivo e pelo alerta de som.
      crossOriginEmbedderPolicy: false
    })
  );
  app.use((_req, res, next) => {
    res.setHeader('Permissions-Policy', 'microphone=(self), geolocation=(), camera=()');
    next();
  });

  const allowed = (env.ALLOWED_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  app.use(
    '/api',
    cors({
      origin: allowed.length ? allowed : env.NODE_ENV === 'production' ? false : true,
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      maxAge: 600
    })
  );

  app.use(express.json({ limit: '20kb' }));
  app.use(
    '/api',
    rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Muitas requisições. Aguarde um instante.' } })
  );

  app.use('/api', buildRouter(repo));
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));

  // Frontend estático (mesmo serviço no Render)
  if (existsSync(FRONTEND_DIR)) {
    app.use(express.static(FRONTEND_DIR, { extensions: ['html'], maxAge: env.NODE_ENV === 'production' ? '1h' : 0 }));
  }

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.' });
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, details: err.details });
    console.error(err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  });

  return { app, repo };
}

// Só inicia o servidor quando o arquivo é executado diretamente (não nos testes).
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  const { app, repo } = await createApp();
  app.listen(port, () => {
    console.log(`Libras Acesso rodando em http://localhost:${port} (banco: ${repo.provider})`);
  });
}
