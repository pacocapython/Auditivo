import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

let server;
let base;
const uid = 'aaaaaaaa-1111-2222-3333-bbbbbbbbbbbb';

before(async () => {
  const { app } = await createApp({ DB_PROVIDER: 'memory', NODE_ENV: 'test' });
  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

const get = (p) => fetch(base + p).then(async (r) => ({ status: r.status, body: await r.json().catch(() => null) }));
const send = (method, p, body) =>
  fetch(base + p, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }).then(async (r) => ({
    status: r.status,
    body: await r.json().catch(() => null)
  }));

test('health', async () => {
  const r = await get('/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.body.provider, 'memory');
});

test('lista sinais e busca ignorando acentos', async () => {
  assert.equal((await get('/api/signs')).body.length, 25);
  const r = await get('/api/signs?q=agua');
  assert.ok(r.body.some((s) => s.id === 'agua'));
  const c = await get('/api/signs?category=saude');
  assert.ok(c.body.length > 0 && c.body.every((s) => s.category === 'saude'));
});

test('sinal inexistente e id inválido', async () => {
  assert.equal((await get('/api/signs/nao-existe')).status, 404);
  assert.equal((await get('/api/signs/A%20B')).status, 400);
});

test('favoritos: adicionar, listar, remover', async () => {
  assert.equal((await send('PUT', `/api/users/${uid}/favorites/agua`)).status, 204);
  assert.deepEqual((await get(`/api/users/${uid}/favorites`)).body, ['agua']);
  assert.equal((await send('PUT', `/api/users/${uid}/favorites/inexistente`)).status, 404);
  assert.equal((await send('DELETE', `/api/users/${uid}/favorites/agua`)).status, 204);
  assert.deepEqual((await get(`/api/users/${uid}/favorites`)).body, []);
});

test('tentativas: valida e grava', async () => {
  assert.equal((await send('POST', `/api/users/${uid}/attempts`, { lessonId: 'licao-basico', score: 9, total: 5 })).status, 400);
  assert.equal((await send('POST', `/api/users/${uid}/attempts`, { lessonId: 'licao-x', score: 1, total: 5 })).status, 404);
  assert.equal((await send('POST', `/api/users/${uid}/attempts`, { lessonId: 'licao-basico', score: 4, total: 5 })).status, 201);
  const list = (await get(`/api/users/${uid}/attempts`)).body;
  assert.equal(list.length, 1);
  assert.equal(list[0].score, 4);
});

test('apagar dados do usuário', async () => {
  await send('PUT', `/api/users/${uid}/favorites/casa`);
  assert.equal((await send('DELETE', `/api/users/${uid}`)).status, 204);
  assert.deepEqual((await get(`/api/users/${uid}/favorites`)).body, []);
  assert.deepEqual((await get(`/api/users/${uid}/attempts`)).body, []);
});

test('feedback valida mensagem', async () => {
  assert.equal((await send('POST', '/api/feedback', { message: 'a' })).status, 400);
  assert.equal((await send('POST', '/api/feedback', { message: 'Gostei muito do app' })).status, 201);
});

test('serve o frontend e cabeçalhos de segurança', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
  assert.match(await r.text(), /Libras Acesso/);
});
