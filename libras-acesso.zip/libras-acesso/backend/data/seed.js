import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));

/** Remove acentos e deixa em minúsculas, para busca que ignora acentuação. */
export function normalize(text) {
  return String(text ?? '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim();
}

/** Lê o seed.json e calcula o campo de busca de cada sinal. */
export function loadSeed() {
  const raw = JSON.parse(readFileSync(path.join(here, 'seed.json'), 'utf8'));
  const categoryName = new Map(raw.categories.map((c) => [c.id, c.name]));
  const signs = raw.signs.map((s) => ({
    ...s,
    searchText: normalize(`${s.word} ${s.description} ${categoryName.get(s.category) ?? ''}`)
  }));
  return { ...raw, signs };
}
