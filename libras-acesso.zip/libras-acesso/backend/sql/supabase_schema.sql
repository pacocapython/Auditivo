-- Libras Acesso - esquema para Supabase (Postgres)
-- Cole no SQL Editor do painel do Supabase e execute. É idempotente.

create table if not exists public.categories (
  id         text primary key,
  name       text not null,
  icon       text,
  sort_order int  not null default 0
);

create table if not exists public.signs (
  id          text primary key,
  word        text not null,
  category_id text not null references public.categories (id),
  emoji       text,
  description text not null,
  tip         text,
  video_url   text,
  image_url   text,
  validated   boolean not null default false,
  search_text text not null default '',
  created_at  timestamptz not null default now()
);
create index if not exists idx_signs_category on public.signs (category_id);
create index if not exists idx_signs_word on public.signs (word);

create table if not exists public.lessons (
  id          text primary key,
  title       text not null,
  description text,
  sort_order  int  not null default 0
);

create table if not exists public.lesson_signs (
  lesson_id text not null references public.lessons (id) on delete cascade,
  sign_id   text not null references public.signs (id)   on delete cascade,
  position  int  not null default 0,
  primary key (lesson_id, sign_id)
);

create table if not exists public.phrases (
  id         text primary key,
  text       text not null,
  category   text not null,
  urgent     boolean not null default false,
  sort_order int not null default 0
);

-- Dados de usuário (identificador anônimo gerado no aparelho)
create table if not exists public.favorites (
  user_id    text not null,
  sign_id    text not null references public.signs (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, sign_id)
);

create table if not exists public.attempts (
  id         bigint generated always as identity primary key,
  user_id    text not null,
  lesson_id  text not null references public.lessons (id) on delete cascade,
  score      int  not null,
  total      int  not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_attempts_user on public.attempts (user_id, id desc);

create table if not exists public.feedback (
  id         bigint generated always as identity primary key,
  user_id    text,
  message    text not null,
  contact    text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Segurança (RLS)
-- Catálogo: leitura pública. Dados de usuário: nenhuma policy,
-- ou seja, só a service_role (servidor) consegue ler e gravar.
-- ---------------------------------------------------------------
alter table public.categories   enable row level security;
alter table public.signs        enable row level security;
alter table public.lessons      enable row level security;
alter table public.lesson_signs enable row level security;
alter table public.phrases      enable row level security;
alter table public.favorites    enable row level security;
alter table public.attempts     enable row level security;
alter table public.feedback     enable row level security;

drop policy if exists "catalogo publico" on public.categories;
drop policy if exists "catalogo publico" on public.signs;
drop policy if exists "catalogo publico" on public.lessons;
drop policy if exists "catalogo publico" on public.lesson_signs;
drop policy if exists "catalogo publico" on public.phrases;

create policy "catalogo publico" on public.categories   for select using (true);
create policy "catalogo publico" on public.signs        for select using (true);
create policy "catalogo publico" on public.lessons      for select using (true);
create policy "catalogo publico" on public.lesson_signs for select using (true);
create policy "catalogo publico" on public.phrases      for select using (true);

-- ---------------------------------------------------------------
-- Vídeos dos sinais (opcional): crie um bucket público no Storage
-- chamado "sign-videos", envie os arquivos e grave a URL pública em
-- signs.video_url. Exemplo:
--   update public.signs set video_url = 'https://SEU-PROJETO.supabase.co/storage/v1/object/public/sign-videos/obrigado.mp4',
--                           validated = true
--   where id = 'obrigado';
-- ---------------------------------------------------------------
