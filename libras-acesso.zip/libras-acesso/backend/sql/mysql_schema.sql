-- Libras Acesso - esquema MySQL 8 / MariaDB 10.5+
-- Idempotente: pode ser executado mais de uma vez.
-- utf8mb4_unicode_ci ignora acentos e maiúsculas nas comparações.

CREATE TABLE IF NOT EXISTS categories (
  id          VARCHAR(40)  NOT NULL,
  name        VARCHAR(80)  NOT NULL,
  icon        VARCHAR(16)  NULL,
  sort_order  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS signs (
  id           VARCHAR(60)  NOT NULL,
  word         VARCHAR(120) NOT NULL,
  category_id  VARCHAR(40)  NOT NULL,
  emoji        VARCHAR(16)  NULL,
  description  TEXT         NOT NULL,
  tip          TEXT         NULL,
  video_url    VARCHAR(500) NULL,
  image_url    VARCHAR(500) NULL,
  validated    TINYINT(1)   NOT NULL DEFAULT 0,
  search_text  TEXT         NOT NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_signs_category (category_id),
  KEY idx_signs_word (word),
  CONSTRAINT fk_signs_category FOREIGN KEY (category_id) REFERENCES categories (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lessons (
  id          VARCHAR(60)  NOT NULL,
  title       VARCHAR(120) NOT NULL,
  description TEXT         NULL,
  sort_order  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lesson_signs (
  lesson_id VARCHAR(60) NOT NULL,
  sign_id   VARCHAR(60) NOT NULL,
  position  INT         NOT NULL DEFAULT 0,
  PRIMARY KEY (lesson_id, sign_id),
  CONSTRAINT fk_ls_lesson FOREIGN KEY (lesson_id) REFERENCES lessons (id) ON DELETE CASCADE,
  CONSTRAINT fk_ls_sign   FOREIGN KEY (sign_id)   REFERENCES signs (id)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS phrases (
  id          VARCHAR(60)  NOT NULL,
  text        VARCHAR(300) NOT NULL,
  category    VARCHAR(40)  NOT NULL,
  urgent      TINYINT(1)   NOT NULL DEFAULT 0,
  sort_order  INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- user_id é um identificador anônimo gerado no aparelho (UUID).
-- Para contas reais, troque por um id de usuário autenticado.
CREATE TABLE IF NOT EXISTS favorites (
  user_id    VARCHAR(64) NOT NULL,
  sign_id    VARCHAR(60) NOT NULL,
  created_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, sign_id),
  CONSTRAINT fk_fav_sign FOREIGN KEY (sign_id) REFERENCES signs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attempts (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    VARCHAR(64)  NOT NULL,
  lesson_id  VARCHAR(60)  NOT NULL,
  score      INT          NOT NULL,
  total      INT          NOT NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_user (user_id, id),
  CONSTRAINT fk_att_lesson FOREIGN KEY (lesson_id) REFERENCES lessons (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feedback (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    VARCHAR(64)  NULL,
  message    TEXT         NOT NULL,
  contact    VARCHAR(200) NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
