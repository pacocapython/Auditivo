// Gera:
//  1) frontend/js/data.js          dados de exemplo para uso offline (a partir de data/seed.json)
//  2) prototype/libras-acesso-prototipo.html   protótipo em um único arquivo (abre com duplo clique)
//
// Uso: npm run build
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadSeed } from '../data/seed.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const frontend = path.join(root, 'frontend');
const read = (...parts) => readFileSync(path.join(frontend, ...parts), 'utf8');

// 1) Dados offline -----------------------------------------------------------
const seed = loadSeed();
const offline = {
  categories: seed.categories.map(({ sortOrder, ...c }) => c),
  signs: seed.signs.map(({ searchText, ...s }) => s),
  lessons: seed.lessons.map(({ sortOrder, ...l }) => l),
  phrases: seed.phrases
};
writeFileSync(
  path.join(frontend, 'js/data.js'),
  `// Gerado por backend/scripts/build.js a partir de backend/data/seed.json. Não edite à mão.\nexport const OFFLINE_DATA = ${JSON.stringify(offline, null, 2)};\n`
);
console.log('frontend/js/data.js gerado.');

// 2) Protótipo de arquivo único ---------------------------------------------
const order = ['storage', 'ui', 'data', 'api', 'state', 'a11y', 'router', 'dictionary', 'alphabet', 'learn', 'communicate', 'captions', 'soundalert', 'progress', 'app'];

const topLevelNames = new Map();
const bundle = order
  .map((name) => {
    let source = read('js', `${name}.js`);
    source = source.replace(/^import[\s\S]*?from\s+['"][^'"]+['"];?[ \t]*$/gm, '');
    source = source.replace(/^export\s+(?=(const|let|function|async function|class)\b)/gm, '');
    for (const match of source.matchAll(/^(?:const|let|function|async function|class)\s+([A-Za-z_$][\w$]*)/gm)) {
      if (topLevelNames.has(match[1])) throw new Error(`Nome duplicado no bundle: "${match[1]}" (${topLevelNames.get(match[1])} e ${name}.js)`);
      topLevelNames.set(match[1], `${name}.js`);
    }
    if (/^\s*(import|export)\s/m.test(source)) throw new Error(`Sobrou import/export em ${name}.js`);
    return `// ---- ${name}.js ----\n${source}`;
  })
  .join('\n');

const config = read('config.js').replace('PWA: true', 'PWA: false');
const css = read('css', 'styles.css');
const html = read('index.html');

const standalone = html
  .replace(/\s*<link rel="manifest"[^>]*>/, '')
  .replace(/\s*<link rel="icon"[^>]*>/, '')
  .replace('<link rel="stylesheet" href="css/styles.css">', () => `<style>\n${css}\n</style>`)
  .replace('<script src="config.js"></script>', () => `<script>\n${config}\n</script>`)
  .replace('<script type="module" src="js/app.js"></script>', () => `<script>\n(() => {\n'use strict';\n${bundle}\n})();\n</script>`);

if (/src="js\/|href="css\/|src="config\.js/.test(standalone)) throw new Error('Sobraram referências externas no protótipo.');

const outDir = path.join(root, 'prototype');
mkdirSync(outDir, { recursive: true });
writeFileSync(path.join(outDir, 'libras-acesso-prototipo.html'), standalone);
console.log(`prototype/libras-acesso-prototipo.html gerado (${Math.round(standalone.length / 1024)} KB).`);

// Variante para publicar como artefato: sem doctype/html/head/body (o publicador adiciona).
const bodyMatch = standalone.match(/<body>([\s\S]*)<\/body>/);
const styleMatch = standalone.match(/<style>[\s\S]*?<\/style>/);
const configScript = standalone.match(/<script>[\s\S]*?<\/script>/); // o primeiro script inline é a configuração
if (!bodyMatch || !styleMatch || !configScript) throw new Error('Não foi possível montar a variante para artefato.');
const scratch = process.env.ARTIFACT_OUT;
if (scratch) {
  const page = `<title>Libras Acesso</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n${styleMatch[0]}\n${configScript[0]}\n${bodyMatch[1]}`;
  writeFileSync(scratch, page);
  console.log(`Variante para artefato gerada em ${scratch}`);
}
