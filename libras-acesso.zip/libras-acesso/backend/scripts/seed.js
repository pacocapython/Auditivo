import 'dotenv/config';
import { createRepository } from '../src/db/index.js';
import { loadSeed } from '../data/seed.js';

const provider = (process.env.DB_PROVIDER || 'memory').toLowerCase();

if (provider === 'memory') {
  console.log('DB_PROVIDER=memory não tem o que carregar. Use mysql ou supabase.');
  process.exit(0);
}

const repo = await createRepository();

try {
  if (provider === 'mysql') {
    console.log('Criando tabelas no MySQL...');
    await repo.migrate();
  } else {
    console.log('Supabase: confirme que você rodou sql/supabase_schema.sql no SQL Editor.');
  }

  console.log('Carregando conteúdo inicial...');
  await repo.seed(loadSeed());
  console.log('Pronto.');
  process.exit(0);
} catch (err) {
  console.error('Falha ao carregar os dados:', err.message);
  process.exit(1);
}
